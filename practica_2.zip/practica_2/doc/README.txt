Autores:

Saul Daniel Soriano, 815743
Adrián Fortea Valencia, 815177

----------------------------------------
Decisiones de Diseño
En la declaración de funciones y procedimientos se encuentran unificadas, y se distinguirán en el analisis semántico su características propias, como que en un procedimiento no se pueden poner return con un valor a devolver. Y a la hora de hacer una llamada a las misma se distingue entre la llamada a un prodecimineto y a una función que se presenta como una "expresión".